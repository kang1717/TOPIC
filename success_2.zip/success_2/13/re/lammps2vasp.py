import sys
sys.path.append('/home/sung.w.kang/utill')
from poscar import *

atomic_mass = dict(H=1.01, He=4.00, Li=6.94, Be=9.01, B=10.81, C=12.01,
                   N=14.01, O=16.00, F=19.00, Ne=20.18, Na=22.99, Mg=24.31,
                   Al=26.98, Si=28.09, P=30.97, S=32.07, Cl=35.45, 
                   K=39.10, Ca=40.07, Sc=44.96, Ti=47.87, V=50.94, Cr=52.00,
                   Mn=54.94, Fe=55.85, Co=58.93, Ni=58.69, Cu=63.55, Zn=65.39,
                   Ga=69.72, Ge=72.61, As=74.92, Se=78.96, Br=79.90, Kr=83.80,
                   Rb=85.47, Sr=87.62, Y=88.91, Zr=91.22, Nb=92.91, Mo=95.94,
                   Tc=98.00, Ru=101.07, Rh=102.91, Pd=106.42, Ag=107.87,
                   Cd=112.41, In=114.82, Sn=118.71, Sb=121.76, Te=127.60,
                   I=126.90, Xe=131.29, Cs=132.91, Ba=137.33, La=138.91,
                   Ce=140.12, Pr=140.91, Nd=144.24, Pm=145.00, Sm=150.36,
                   Eu=151.96, Gd=157.25, Tb=158.93, Dy=162.50, Ho=164.93,
                   Er=167.26, Tm=168.93, Yb=173.04, Lu=174.97, Hf=178.49,
                   Ta=180.95, W=183.84, Re=186.21, Os=190.23, Ir=192.22,
                   Pt=195.08, Au=196.97, Hg=200.59, Tl=204.38, Pb=207.2,
                   Bi=208.98, Po=209.00, At=210.00, Rn=222.00, Fr=223.00,
                   Ra=226.00, Ac=227.00, Th=232.04, Pa=231.04, U=238.03,
                   Np=237.00, Pu=244.00, Am=243.00, Cm=247.00, Bk=247.00,
                   Cf=251.00, Es=252.00, Fm=257.00, Md=258.00, No=259.00,
                   Lr=262.00, Rf=261.00, Db=262.00, Sg=266.00, Bh=264.00,
                   Hs=269.00, Mt=268.00)

try:
    LammpsLines = open(sys.argv[1]).readlines()
except:
    print ('Usage: python -.py LammpsStruct > POSCAR')
    sys.exit()

#------------------------- simple structure file part -----------------------#
LatticeVector = [[0,0,0],[0,0,0],[0,0,0]]
name = LammpsLines[0]
#if '#' == LammpsLines[0][0]:
#    name = LammpsLines[0].split('#',1)[1]
for cnt in range(1,len(LammpsLines)):
    if 'atoms' in LammpsLines[cnt]:
        numIon = int(LammpsLines[cnt].split()[0])
    elif 'atom types' in LammpsLines[cnt]:
        numElements = int(LammpsLines[cnt].split()[0])
    elif 'xlo' in LammpsLines[cnt]:
        LatticeVector[0][0] = float(LammpsLines[cnt].split()[1]) - float(LammpsLines[cnt].split()[0])
    elif 'ylo' in LammpsLines[cnt]:
        LatticeVector[1][1] = float(LammpsLines[cnt].split()[1]) - float(LammpsLines[cnt].split()[0])
    elif 'zlo' in LammpsLines[cnt]:
        LatticeVector[2][2] = float(LammpsLines[cnt].split()[1]) - float(LammpsLines[cnt].split()[0])
    elif 'xy' in LammpsLines[cnt]:
        LatticeVector[1][0] = float(LammpsLines[cnt].split()[0])
        LatticeVector[2][0] = float(LammpsLines[cnt].split()[1])
        LatticeVector[2][1] = float(LammpsLines[cnt].split()[2])
    elif 'Masses' in LammpsLines[cnt]:
        MassesLines = []
        cursor = 0
        while True:
            cursor += 1
            if LammpsLines[cnt+cursor].split() != []:
                MassesLines.append(LammpsLines[cnt+cursor])
            if len(MassesLines) == numElements:
                break
    elif 'Atoms' in LammpsLines[cnt]:
        AtomsLines = []
        cursor = 0
        while True:
            cursor += 1
            if LammpsLines[cnt+cursor].split() != []:
                AtomsLines.append(LammpsLines[cnt+cursor])
            if len(AtomsLines) == numIon:
                break
MassesLines.sort(key=lambda x: int(x.split()[0]))
AtomsLines.sort(key=lambda x: float(x.split()[4]))   # sort about z coordinate
AtomsLines.sort(key=lambda x: int(x.split()[1]))
ElementList = []
AMItems = list(atomic_mass.items())
for line in MassesLines:
    mass = round(float(line.split()[1]),0)
    for Tup in AMItems:
        if round(Tup[1],0) == mass:
            ElementList.append(Tup[0])
            break
NumIonList = [0]*numElements
Cartesian = []
for line in AtomsLines:
    NumIonList[int(line.split()[1])-1] += 1
    Cartesian.append(line.split()[2:])
#------------------------------------------------------------------#

#------------------------ print scripts -----------------------------#
printBuffer = ''
printBuffer += '(Converted from LAMMPS) '+name+' 1.0\n'
for rowCnt in range(3):
    for colCnt in range(3):
        printBuffer += '   %12.8f ' %float(LatticeVector[rowCnt][colCnt])
    printBuffer += '\n'
#for comp in ElementList:
#    printBuffer += '  %s' %comp
#printBuffer += '\n'
#for comp in NumIonList:
#    printBuffer += '  %s' %comp

printBuffer += " Ta P O\n 16 8 64" 
printBuffer += '\nCartesian\n'
for rowCnt in range(numIon):
    for colCnt in range(3):
        printBuffer += '   %12.8f ' %float(Cartesian[rowCnt][colCnt])
    printBuffer += '\n'
print (printBuffer)
#-------------------------------------------------------------------------#
