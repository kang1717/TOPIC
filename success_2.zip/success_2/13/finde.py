import sys

with open('log','r') as f:
  for fline in f:
    if fline.split()[3] == '0' and fline.split()[5] == '0':
      if  float(fline.split()[8]) < -809:     
        print (fline,end='')
